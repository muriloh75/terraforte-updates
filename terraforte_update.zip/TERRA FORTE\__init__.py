# -*- coding: utf-8 -*-
import sys
import os
import subprocess
import importlib
from qgis.PyQt.QtWidgets import QMessageBox

# ==============================================================================
# 1. AUTO-INSTALAÇÃO DE DEPENDÊNCIAS (SCIPY E MATPLOTLIB)
# ==============================================================================
def verificar_e_instalar_dependencias():
    dependencias = ['scipy', 'matplotlib']
    faltando = []
    
    for dep in dependencias:
        try:
            importlib.import_module(dep)
        except ImportError:
            faltando.append(dep)
            
    if faltando:
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setWindowTitle("Terra Forte - Primeira Configuração")
        msg.setText("O Terra Forte está preparando o motor matemático para o seu sistema (Krigagem e NDVI).\n\nIsso pode levar alguns minutos. O QGIS pode parecer travado, por favor, aguarde.")
        msg.exec_()
        
        python_exe = sys.executable
        try:
            subprocess.check_call([python_exe, "-m", "pip", "install"] + faltando)
            msg_ok = QMessageBox()
            msg_ok.setIcon(QMessageBox.Information)
            msg_ok.setWindowTitle("Sucesso")
            msg_ok.setText("Motor matemático instalado! O Terra Forte está pronto para uso.")
            msg_ok.exec_()
        except subprocess.CalledProcessError as e:
            pass

verificar_e_instalar_dependencias()

# ==============================================================================
# 2. MAPEAMENTO DO RUNTIME PYARMOR (CORRIGIDO)
# ==============================================================================
plugin_dir = os.path.dirname(__file__)

# 🚀 CORREÇÃO VITAL: Sempre injetar a pasta no sys.path ANTES de qualquer coisa!
# Isso impede que o QGIS fique cego devido ao espaço no nome "TERRA FORTE"
if plugin_dir not in sys.path:
    sys.path.insert(0, plugin_dir)

nome_runtime = None
for item in os.listdir(plugin_dir):
    if item.startswith("pyarmor_runtime_") and os.path.isdir(os.path.join(plugin_dir, item)):
        nome_runtime = item
        break

if nome_runtime:
    try:
        # Importa de forma absoluta usando o sys.path que acabamos de configurar
        runtime_mod = __import__(nome_runtime)
        sys.modules[nome_runtime] = runtime_mod
    except Exception:
        pass

# ==============================================================================
# 3. INICIALIZAÇÃO DO PLUGIN NO QGIS
# ==============================================================================
def classFactory(iface):
    from .terra_forte_plugin import TerraFortePlugin
    return TerraFortePlugin(iface)