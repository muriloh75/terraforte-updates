# -*- coding: utf-8 -*-
import sys
import os
import subprocess
import importlib
from qgis.PyQt.QtWidgets import QMessageBox

def verificar_e_instalar_dependencias():
    dependencias = ['scipy', 'matplotlib']
    faltando = []
    
    for dep in dependencias:
        try:
            importlib.import_module(dep)
        except ImportError:
            faltando.append(dep)
            
    if faltando:
        # Avisa o usuário que o QGIS vai fazer um download rápido
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setWindowTitle("Terra Forte - Primeira Configuração")
        msg.setText("O Terra Forte está preparando o motor matemático para o seu sistema (Krigagem e NDVI).\n\nIsso pode levar alguns minutos. O QGIS pode parecer travado, por favor, aguarde.")
        msg.exec_()
        
        # O sys.executable pega o Python interno do QGIS, seja no Mac ou Windows
        python_exe = sys.executable
        
        try:
            # Roda o pip install silenciosamente
            subprocess.check_call([python_exe, "-m", "pip", "install"] + faltando)
            
            msg_ok = QMessageBox()
            msg_ok.setIcon(QMessageBox.Information)
            msg_ok.setWindowTitle("Sucesso")
            msg_ok.setText("Motor matemático instalado! O Terra Forte está pronto para uso.")
            msg_ok.exec_()
            
        except subprocess.CalledProcessError as e:
            msg_erro = QMessageBox()
            msg_erro.setIcon(QMessageBox.Critical)
            msg_erro.setWindowTitle("Erro de Instalação")
            msg_erro.setText(f"Não foi possível instalar as dependências automaticamente.\nErro: {e}")
            msg_erro.exec_()

# 0. Verifica se o Mac/Windows tem o Scipy e Matplotlib e instala se precisar
verificar_e_instalar_dependencias()

# 1. Ensina o QGIS a achar a pasta secreta do PyArmor
plugin_dir = os.path.dirname(__file__)
if plugin_dir not in sys.path:
    sys.path.insert(0, plugin_dir)

# 2. Inicia o Plugin Blindado
def classFactory(iface):
    from .terra_forte_plugin import TerraFortePlugin
    return TerraFortePlugin(iface)