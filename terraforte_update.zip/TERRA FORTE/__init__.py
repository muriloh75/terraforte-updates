# -*- coding: utf-8 -*-
import sys
import os

# 1. Ensina o QGIS a achar a pasta secreta do PyArmor
plugin_dir = os.path.dirname(__file__)
if plugin_dir not in sys.path:
    sys.path.insert(0, plugin_dir)

# 2. Inicia o Plugin Blindado
def classFactory(iface):
    from .terra_forte_plugin import TerraFortePlugin
    return TerraFortePlugin(iface)