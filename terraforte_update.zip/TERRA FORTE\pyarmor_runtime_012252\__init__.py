# Pyarmor 9.2.4 (basic), 012252, 2026-05-18T21:52:53.903186
from sys import version_info as py_version
__pyarmor__ = __import__("py%d%d.pyarmor_runtime" % py_version[:2], globals(), locals(), ["__pyarmor__"], 1).__pyarmor__